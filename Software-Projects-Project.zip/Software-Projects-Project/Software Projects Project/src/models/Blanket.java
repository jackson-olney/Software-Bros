package models;

public class Blanket extends Item{
    @Override
    public String toString(){
        return "Blanket";
    }
}
