package models;

public class Cheese extends Item{
    @Override
    public String toString(){
        return "Cheese";
    }
}
