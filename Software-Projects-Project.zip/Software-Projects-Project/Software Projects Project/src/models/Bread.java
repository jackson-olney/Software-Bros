package models;

public class Bread extends Item{
    @Override
    public String toString(){
        return "Bread";
    }
}
