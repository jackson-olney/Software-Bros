package models;

public class Item {
    public static void itemLocation(){

    }
}
