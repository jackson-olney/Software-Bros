package models;

public class Flyswatter extends Item{
    @Override
    public String toString(){
        return "Flyswatter";
    }
}
