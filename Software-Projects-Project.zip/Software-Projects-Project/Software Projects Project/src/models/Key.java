package models;

public class Key extends Item{
    @Override
    public String toString(){
        return "key";
    }
}
