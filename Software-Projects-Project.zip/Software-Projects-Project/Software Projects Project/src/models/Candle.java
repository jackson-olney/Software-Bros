package models;

public class Candle extends Item{
    @Override
    public String toString(){
        return "Candle";
    }
}
