package models;

import com.sun.deploy.config.JREInfo;

import java.util.ArrayList;
import java.util.List;

public class Person {

    private static String name; //optional to add name?
    private static List<Item> inventory = new ArrayList<>();

    public Person(){
    }

    public Person(String name, List<Item> inventory) {
        this.name = name;
        this.inventory = inventory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Item> getInventory() {
        return inventory;
    }

    public void setInventory(List<Item> inventory) {
        this.inventory = inventory;
    }

    public void addInventory(Item item){
        inventory.add(item);
        //inventory added message?
    }
    public void removeInventory(Item item){
        inventory.remove(item);
        //inventory remove message?
    }
    public static void clearInventory(){
        inventory.clear();
    }
    public static boolean currentState(){
        boolean isAlive = true;
        return isAlive;
    }

    @Override
    public String toString() {
        return "Name: " + getName() + "\nInventory: " + getInventory() ;
    }
}
