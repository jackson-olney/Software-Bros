package controllers;

//import lib.ConsoleIO;
import models.*;
import views.View;

import java.io.IOException;

public class Controller {

    private View view = new View();
    private Person person = new Person();

    //Items:
    private static Blanket blanket = new Blanket();
    private static Bread bread = new Bread();
    private static Candle candle = new Candle();
    private static Cheese cheese = new Cheese();
    private static Flyswatter flyswatter = new Flyswatter();
    private static Matches matches = new Matches();
    private static Key key = new Key();

    public static int position = 0;

    public static boolean gameOver = false;

    public static boolean personIsAlive = Person.currentState();

    public static void currentPosition() {

        //String direction = ConsoleIO.promptForString("Where do you want to go?:")

        //Rooms:
        Room bloodRoom = new Room();
        Room eerieHallway = new Room();
        Room deathsCloset = new Room();
        Room theeRoom = new Room();
        Room deadMansMudRoom = new Room();
        Room heavensInsight = new Room();
        Room theBasement = new Room();

        //Item Placement:
        bloodRoom.addItem(blanket);
        eerieHallway.addItem(candle);
        deathsCloset.addItem(matches);
        theeRoom.addItem(flyswatter);
        deadMansMudRoom.addItem(bread);
        heavensInsight.addItem(cheese);
        theBasement.addItem(key);

        position = 0;
        Person.clearInventory();


        do {
            winCondition();

        }while(!gameOver);
    }


//    public Controller(){
//    }
//
//    public void run() throws IOException {
//        boolean quit = false;
//        do {
//            view.beginningLocation();
//            String userSelection = view.getUserInput();
//
//            if(userSelection.equals("go north") || userSelection.equals("n")){
//                view.showMessage("You moved north! You are now in the (hallway)");
//                break;
//            } else if(userSelection.equals("go east") || userSelection.equals("e")){
//                view.showMessage("You moved east! You are now in the (hallway)");
//                break;
//            } else if(userSelection.equals("go south") || userSelection.equals("s")){
//                view.showMessage("You moved south! You are now in the (hallway)");
//                break;
//            } //more else if movements for the rest of the directions
//            else if(userSelection.equals("show inventory")) {
//                showInventory();
//                break;
//            }
//            else if(userSelection.equals("quit") || userSelection.equals("q")){
//                quit = true;
//            }
//            else{
//                view.showError("Incorrect input. Please try again.");
//            }
//        }while(!quit);
//    }



    public void testing(){
        person.setName("Jimmy");
        person.addInventory(cheese);
        person.addInventory(bread);
        person.removeInventory(bread);
        //System.out.println(person.getInventory());
        System.out.println(person.toString());
    }

    public void showInventory() {
        person.addInventory(cheese);
        person.addInventory(bread);
        System.out.println("\n" + "Inventory: \n");
        for (Item i : person.getInventory()) {
            System.out.println(i);
        }
    }

    public boolean checkInventory(String userInventorySelection) {
        for (Item inventory : person.getInventory())
            if (inventory.equals(userInventorySelection)) {
                return true;
            }
        return false;
    }

    public static boolean winCondition(){
        if(!personIsAlive){
            gameOver = true;
        }
        return gameOver;
    }

}
