package prog;

import controllers.Controller;

import java.io.IOException;

public class Main {

    private static Controller controller = new Controller();

    public static void main(String[] args) throws IOException {
        //controller.run();
        //controller.testing();
        controller.currentPosition();
    }
}
