package prog;

import java.io.*;
import java.util.Scanner;

public class Commands {

    public void move(){

    }

    public void showHelpMenu(){
        try {
            File help = new File("Software Projects Project/help.txt");
            Scanner scan = new Scanner(help);
            while (scan.hasNextLine()) {
                System.out.println(scan.nextLine());
            }
        } catch (IOException ex){
            System.out.println("File not Found");
            ex.printStackTrace();
        }
    }
}
