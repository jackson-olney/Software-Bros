package prog;

import views.View;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Controller {

    private View view = new View();
    private Person person = new Person();

    public Controller(){
    }

    public void run() throws IOException {
        person.setLocation("center");
        boolean quit = false;
        view.beginningLocation();
        label:
        do {
            String userSelection = view.getUserInput();

            switch (userSelection) {
                case "go north":
                case "n":
                    movement("south", "north");
                    break;
                case "go east":
                case "e":
                    movement("west", "east");
                    break;
                case "go south":
                case "s":
                    movement("north", "south");
                    break;
                case "go west":
                case "w":
                    movement("east", "west");
                    break;
                case "go up":
                case "u":
                    movement("down", "up");
                    break;
                case "go down":
                case "d":
                    movement("up", "down");
                    break;
                case "show inventory":
                    showInventory();
                    break label;
                case "quit":
                case "q":
                    quit = true;
                    break;
                default:
                    view.showError("Incorrect input. Please try again.");
                    break;
            }
        }while(!quit);
    }

    public void testing(){
        person.setName("Jimmy");
        person.addInventory("cheese");
        person.addInventory("bread");
        person.removeInventory("bread");
        //System.out.println(person.getInventory());
        System.out.println(person.toString());
    }

    public void showInventory() {
        person.addInventory("cheese");
        person.addInventory("bread");
        System.out.println("\n" + "Inventory: \n");
        for (String s : person.getInventory()) {
            System.out.println(s);
        }
    }

    public boolean checkInventory(String userInventorySelection) {
        for (String inventory : person.getInventory())
            if (inventory.equals(userInventorySelection)) {
                return true;
            }
        return false;
    }


    public void movement(String requiredMove, String movement){
        if(person.getLocation().equals("center")){
            view.showMessage("You moved " + movement);
            person.setLocation(requiredMove);
        }
        else if(!movement.equals(person.getLocation())){
            view.showMessage("You cannot move here" );
        }
        else{
            view.showMessage("You moved " + movement);
            person.setLocation("center");
        }
    }
}
