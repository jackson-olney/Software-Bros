package prog;

import java.util.ArrayList;
import java.util.List;

public class Person {

    private String name; //optional to add name?
    private List<String> inventory = new ArrayList<>();
    private String location;



    public Person(){
    }

    public Person(String name, List<String> inventory) {
        this.name = name;
        this.inventory = inventory;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getInventory() {
        return inventory;
    }

    public void setInventory(List<String> inventory) {
        this.inventory = inventory;
    }

    public void addInventory(String piece){
        inventory.add(piece);
        //inventory added message?
    }
    public void removeInventory(String piece){
        inventory.removeIf(var -> var.contains(piece));
        //inventory remove message?
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Name: " + getName() + "\nInventory: " + getInventory() ;
    }
}
