package views;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class View {

    private BufferedReader in;

    public View(){
        InputStreamReader inputStreamReader = new InputStreamReader(System.in);
        in = new BufferedReader(inputStreamReader);
    }

    public void beginningLocation(){
        System.out.println("You are currently in the (hallway)..\n" +
                "Enter \"go \" following any of these key words below to move your character\nor enter \"show inventory\" to see your character's inventory.  \n" +
                "North, East, South, West, Up, or Down (Ex: go south) : ");
    }

    public String getUserInput() throws IOException {
        return in.readLine();
    }

    public void showMessage(String msg){
        System.out.println(msg);
    }

    public void showError(String msg){
        System.err.println(msg);
    }
}


